﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OS_Project
{
    class Node
    {
        private
	int data;
	Node nextNode=new Node();
	Node preNode=new Node();
public
	Node ()
	{
		data=0;
        nextNode = null;
		preNode= null;
	}

	Node (int d)
	{
		data=d;
        nextNode = null;
        preNode = null;
	}

	void setdata(int d)
	{
		data=d;
	}

	int getdata()
	{
		return data;
	}

	void setnextNode(Node next )
	{
		nextNode=next;
	}

	Node  getnextNode()
	{
		return nextNode;
	}

	void setpreNode(Node  pre )
	{
		preNode=pre;
	}

	Node  getpreNode()
	{
		return preNode;
	}
    }
}
