﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OS_Project
{
    public partial class Form1 : Form
    {
        
        string path = @"G:\ds project\OS Project\OS Project\CustomerFile.txt";
        string dequeuepath = @"G:\ds project\OS Project\OS Project\DequeueCustomerFile.txt";
        Queue cusQue = new Queue();
        Customer cus = new Customer();
        Random rnd = new Random();
        int queueValue = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void AddCustomer() // this function will enter customer info into queue and file
        {
            try
            {
                    queueValue++;
                    cus.custId++;
                    cus.serviceTime = 0;
                    cus.arriveTime = rnd.Next(0, 40);
                    cus.shopTime = rnd.Next(0, 100);
                    cus.serviceTime = cus.serviceTime + cus.shopTime;
                    cus.waitTime = cus.turnAroundTime - cus.serviceTime;
                    cus.turnAroundTime = cus.shopTime - cus.arriveTime;
                    cus.responseTime = cus.waitTime;
                    cusQue.Enqueue(cus.custId);
                    appendToFile(cus);
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void wait()// this will remove a customer from the queue if the queue is full
        {
            queueValue--;
            removedCustomer(cus);
            AddCustomer();
        }


        private void signal()// this locking mechanism will check if the user enter 4 or mor time to the queue and dequeue 1 customer          
        {
            if (queueValue <= 4)
            {
                AddCustomer();

            }
            else
            {
                wait();
            }
        }


        private void removedCustomer(Customer cus)// this function wll dequeue a customer if it exceed 4
        {
              try
                {
                    cusQue.Dequeue(); // dequeue a customer if it exceed 4
                    DequeCustomerFile(cus);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message); // error messgae
                }
        }


        private void writeTofile(Customer cus)//this function will create a new file instance for both queue and queue file methods
        {
            // Create a file to write to. 
            using (StreamWriter write = File.CreateText(dequeuepath))
            {       //stores all the customer info to the file
                write.WriteLine("the shopping time is: "+cus.shopTime);
                write.WriteLine("the arrived time is: " + cus.arriveTime);
                write.WriteLine("the response time is: " + cus.responseTime);
                write.WriteLine("the waiting time is: " + cus.waitTime);
                write.WriteLine("the turn around time is: " + cus.turnAroundTime);
            }	
        }

        private void appendToFile(Customer cus)//this function will append the other info to file for 50 times
        {            
            if (File.Exists(path))
            {
                using (StreamWriter write = File.AppendText(path))
                {
                    write.WriteLine(" ");
                    write.WriteLine(cus.custId);
                    write.WriteLine("the shopping time is: " + cus.shopTime);
                    write.WriteLine("the arrived time is: " + cus.arriveTime);
                    write.WriteLine("the response time is: " + cus.responseTime);
                    write.WriteLine("the waiting time is: " + cus.waitTime);
                    write.WriteLine("the turn around time is: " + cus.turnAroundTime);
                    write.WriteLine(" ");
                    write.WriteLine(" ");
                }
            }
        }

        private void DequeCustomerFile(Customer cus)//each time a customer is dequeue it is write to this file
        {
           
            if (File.Exists(dequeuepath))
            {
                // Create a file to write to. 
                using (StreamWriter read = File.AppendText(dequeuepath))
                {
                    read.WriteLine(" ");
                    read.WriteLine(cus.custId);
                    read.WriteLine("the shopping time is: " + cus.shopTime);
                    read.WriteLine("the arrived time is: " + cus.arriveTime);
                    read.WriteLine("the response time is: " + cus.responseTime);
                    read.WriteLine("the waiting time is: " + cus.waitTime);
                    read.WriteLine("the turn around time is: " + cus.turnAroundTime);
                    read.WriteLine(" ");
                    read.WriteLine(" ");
                }
            }
        }

       
        private void readfile()//this function will read all the file info and display it to the screen
        {
            string[] lines = System.IO.File.ReadAllLines (path);
            // Display the file contents by using a foreach loop.
            foreach (string line in lines)
            {
                listView1.Items.Add(new ListViewItem(line)); //display all the customer info to the screen
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 50; i++)
            {
                signal();
            }
            readfile();
        }
    }
}
