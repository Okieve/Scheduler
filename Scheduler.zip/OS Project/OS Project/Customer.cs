﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OS_Project
{
    class Customer
    {
       public  int custId {set;get;}
       public double waitTime { set; get; }
       public double arriveTime { set; get; }
       public double shopTime { set; get; }
       public double serviceTime { set; get; }
       public double responseTime { set; get; }
       public double turnAroundTime { set; get; }
    }
}
